package com.de.status;

/**
 * Class that store information about dead status
 */
public class DeadStatus extends StatusAbstract {
}
